package com.cinglevue.schools.appication.school;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cinglevue.schools.domain.school.School;
import com.cinglevue.schools.domain.school.SchoolService;

@Service
public class SchoolApplicationService {

	@Autowired
	private SchoolService schoolService;

	public SchoolResponseDTO createSchool(SchoolDTO requestDTO) {

		School school = SchoolTansformer.toSchool(requestDTO);

		school = schoolService.createSchool(school);

		return SchoolTansformer.toSchoolResponseDTO(school);
	}

}
