package com.cinglevue.schools.appication.school;

import com.cinglevue.schools.domain.school.School;

public class SchoolTansformer {

	public static School toSchool(SchoolDTO requestDTO) {
		School school = new School();
		
		school.setSchoolName(requestDTO.getSchoolName());
		
		return school;
	}

	public static SchoolResponseDTO toSchoolResponseDTO(School school) {
		SchoolResponseDTO responseDTO = new SchoolResponseDTO();
		
		responseDTO.setSchoolId(school.getSchoolId());

		return responseDTO;
	}

}
