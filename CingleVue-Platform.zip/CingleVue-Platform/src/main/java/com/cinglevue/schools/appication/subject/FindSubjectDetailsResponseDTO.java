package com.cinglevue.schools.appication.subject;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cinglevue.schools.appication.util.ResultsPagingDTO;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FindSubjectDetailsResponseDTO {

	private List<SubjectDetailDTO> details;

	private ResultsPagingDTO resultPaging;

	public List<SubjectDetailDTO> getDetails() {
		return details;
	}

	public void setDetails(List<SubjectDetailDTO> details) {
		this.details = details;
	}

	public ResultsPagingDTO getResultPaging() {
		return resultPaging;
	}

	public void setResultPaging(ResultsPagingDTO resultPaging) {
		this.resultPaging = resultPaging;
	}

}
