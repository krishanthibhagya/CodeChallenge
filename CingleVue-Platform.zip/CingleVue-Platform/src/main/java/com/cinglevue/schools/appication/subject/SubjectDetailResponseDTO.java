package com.cinglevue.schools.appication.subject;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubjectDetailResponseDTO {

	private String subjectDetailsId;

	public String getSubjectDetailsId() {
		return subjectDetailsId;
	}

	public void setSubjectDetailsId(String subjectDetailsId) {
		this.subjectDetailsId = subjectDetailsId;
	}

}
