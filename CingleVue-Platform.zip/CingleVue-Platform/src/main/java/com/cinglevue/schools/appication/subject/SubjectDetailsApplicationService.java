package com.cinglevue.schools.appication.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.cinglevue.schools.appication.util.ResultsPagingValidator;
import com.cinglevue.schools.domain.exception.NotFoundException;
import com.cinglevue.schools.domain.school.School;
import com.cinglevue.schools.domain.school.SchoolService;
import com.cinglevue.schools.domain.subject.SubjectDetail;
import com.cinglevue.schools.domain.subject.SubjectDetailsServie;

/**
 * The <code> SubjectDetailsApplicationService </code> is the Application Service <br/>
 * which communicates with Domain Service and the Controller.
 * 
 * @author Krishanthi
 * 
 */
@Service
public class SubjectDetailsApplicationService {

	@Autowired
	private SubjectDetailsServie subjectDetailsServie;

	@Autowired
	private SchoolService schoolService;

	/**
	 * Creates a SubjectDetail.
	 * 
	 * @param schoolId the School Id
	 * @param requestDTO the CreateSubjectDetailRequestDTO
	 * @throws NotFoundException, if School does not exist
	 * @return a SubjectDetailResponseDTO
	 */
	public SubjectDetailResponseDTO createSubjectDetail(String schoolId,
			CreateSubjectDetailRequestDTO requestDTO) {

		School school = schoolService.findSchool(schoolId);

		SubjectDetail subject = SubjectDetailsTranformer.toSubject(school,
				requestDTO);

		subject = subjectDetailsServie.createSubjectDetail(subject);

		return SubjectDetailsTranformer.toSubjectResponseDTO(subject);

	}

	/**
	 * Finds UserDetails by Subject.
	 * 
	 * @param page the page number
	 * @param count the number of records for a page
	 * @param sortBy the sort parameter
	 * @param sortdirection the sort direction
	 * @param subject the subject name
	 * @return a list of UserDetails
	 */
	public FindSubjectDetailsResponseDTO findSubjectDetails(int page,
			int count, String sortBy, Direction sortdirection,String subject) {

		ResultsPagingValidator.validatePageAndCountIndexes(page, count);

		Pageable pageable = new PageRequest(page, count, sortdirection, sortBy);

		Page<SubjectDetail> subjectDetails = subjectDetailsServie
				.findSubjectDetails(subject, pageable);

		return SubjectDetailsTranformer
				.toFindSubjectDetailsResponseDTO(subjectDetails);

	}
}
