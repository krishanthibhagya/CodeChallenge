package com.cinglevue.schools.appication.subject;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;

import com.cinglevue.schools.appication.school.SchoolDTO;
import com.cinglevue.schools.appication.util.ResultsPagingDTO;
import com.cinglevue.schools.domain.school.School;
import com.cinglevue.schools.domain.subject.SubjectDetail;

/**
 * The <code> SubjectDetailsTranformer </code> is used to transform SubjectDetail related objects.
 * 
 * @author Krishanthi
 *
 */
public class SubjectDetailsTranformer {

	/**
	 * Transforms a CreateSubjectDetailRequestDTO to a SubjectDetail.
	 * 
	 * @param school a School
	 * @param requestDTO a CreateSubjectDetailRequestDTO
	 * @return a SubjectDetail
	 */
	public static SubjectDetail toSubject(School school,
			CreateSubjectDetailRequestDTO requestDTO) {
		SubjectDetail subjectDetails = new SubjectDetail();

		subjectDetails.setLatestY3(requestDTO.getLatestY3());
		subjectDetails.setSubject(requestDTO.getSubject());
		subjectDetails.setSchool(school);

		return subjectDetails;
	}

	/**
	 * Transforms a SubjectDetail to a SubjectDetailResponseDTO.
	 * 
	 * @param subjectDetail a SubejctDetail
	 * @return a SubjectDetailResponseDTO
	 */
	public static SubjectDetailResponseDTO toSubjectResponseDTO(
			SubjectDetail subjectDetail) {
		SubjectDetailResponseDTO responseDTO = new SubjectDetailResponseDTO();

		responseDTO.setSubjectDetailsId(subjectDetail.getSubectDetailsId());

		return responseDTO;
	}

	/**
	 * Transforms a SubjectDetail list to a FindSubjectDetailsResponseDTO.
	 * 
	 * @param subjectDetails a list of SubjectDetail
	 * @return a FindSubjectDetailsResponseDTO
	 */
	public static FindSubjectDetailsResponseDTO toFindSubjectDetailsResponseDTO(
			Page<SubjectDetail> subjectDetails) {
		FindSubjectDetailsResponseDTO responseDTO = new FindSubjectDetailsResponseDTO();

		ResultsPagingDTO pagingDTO = ResultsPagingDTO.getInstance(
				subjectDetails.getTotalElements(), subjectDetails.getSize(),
				subjectDetails.getTotalPages(), subjectDetails.getNumber());
		
		responseDTO.setResultPaging(pagingDTO);
		 
		List<SubjectDetailDTO> detailDTOs = toSubjectDetailDTOList(subjectDetails.getContent());
		
		responseDTO.setDetails(detailDTOs);

		return responseDTO;
	}

	/**
	 * Transforms SubjectDetail list to SubjectDetailDTO list.
	 * @param subjectDetails
	 * @return a ubjectDetailDTO list
	 */
	private static List<SubjectDetailDTO> toSubjectDetailDTOList(
			List<SubjectDetail> subjectDetails) {
		List<SubjectDetailDTO> dtos = new ArrayList<SubjectDetailDTO>();
		
		for (SubjectDetail subjectDetail : subjectDetails) {
			SubjectDetailDTO dto = new SubjectDetailDTO();
			dto.setSubject(subjectDetail.getSubject());
			dto.setSchool(toSchoolDTO(subjectDetail.getSchool()));
			
			dtos.add(dto);
		}
		  

		return dtos;
	}

	/**
	 * Transforms a School to a SchoolDTO
	 * @param school a School
	 * @return a SchoolDTO
	 */
	private static SchoolDTO toSchoolDTO(School school) {
		SchoolDTO dto = new SchoolDTO();
		
		dto.setSchoolName(school.getSchoolName());

		return dto;
	}

}
