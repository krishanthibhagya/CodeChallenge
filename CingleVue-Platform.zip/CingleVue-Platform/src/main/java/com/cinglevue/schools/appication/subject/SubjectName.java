package com.cinglevue.schools.appication.subject;

public enum SubjectName {
	
	Numeracy, Spelling, Reading;

}
