package com.cinglevue.schools.appication.util;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultsPagingDTO {

	private long total;

	private int count;

	private long totalPages;

	private int currentPage;
	
	public static ResultsPagingDTO getInstance(long total, int count, int totalPages, int currentPage) {
        return new ResultsPagingDTO(total, count, totalPages, currentPage);
    }
    
    public ResultsPagingDTO(){}

    public ResultsPagingDTO(long total, int count, int totalPages, int currentPage) {

        this.total = total;
        this.count = count;
        this.totalPages = totalPages;
        this.currentPage = currentPage;
    }

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public long getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(long totalPages) {
		this.totalPages = totalPages;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

}
