package com.cinglevue.schools.appication.util;

import com.cinglevue.schools.domain.exception.BadRequestException;
import com.cinglevue.schools.domain.exception.CinglevueExceptionCode;

public class ResultsPagingValidator {
	
public static void validatePageAndCountIndexes(int page, int count){
        
        if (page < 0) {
            throw new BadRequestException(CinglevueExceptionCode.INVALID_PAGE_INDEX.toString(),
            		CinglevueExceptionCode.INVALID_PAGE_INDEX.getDescription());
        }
        
        if (count <= 0) {
            throw new BadRequestException(CinglevueExceptionCode.INVALID_PAGE_SIZE.toString(),
            		CinglevueExceptionCode.INVALID_PAGE_SIZE.getDescription());
        }
    }

}
