package com.cinglevue.schools.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cinglevue.schools.domain.exception.CinglevueExceptionCode;
import com.cinglevue.schools.domain.exception.HTTPException;

public abstract class HTTPResponseHandler {

	private static final String STATUS_CODE = "cinglevue-code";

	private static final String STATUS_MESSAGE = "cinglevue-message";

	private static final Logger logger = LoggerFactory
			.getLogger(HTTPResponseHandler.class);

	public void setStatusHeaders(HttpServletResponse response, String code,
			String message) {
		response.setHeader(STATUS_CODE, code);
		response.setHeader(STATUS_MESSAGE, message);
	}

	public void setStatusHeadersToSuccess(HttpServletResponse response) {
		setStatusHeaders(response, "SUCCESS", "Success");
	}

	 @ExceptionHandler(HTTPException.class)
	    public void handleHTTPException(HTTPException ex, HttpServletRequest request, HttpServletResponse response) {

	        String code = ex.getStatusCode();
	        String message = ex.getStatusMessage();

	        int status = ex.getHttpStatus().value();

	        response.setStatus(status);

	        setStatusHeaders(response, code, message);

	        logger.error(ex.getMessage());
	    }


	    /**
	     * Handles MethodArgumentNotValidException, HttpMessageNotReadableException or generic Exception
	     * 
	     * @param ex the thrown Exception
	     * @param request the request
	     * @param response the response
	     */
	    @ExceptionHandler(Exception.class)
	    public void handleException(Exception ex, HttpServletRequest request, HttpServletResponse response) {

	        String code = "";
	        String message = "";
	        int status = 0;

	        ex.printStackTrace();

	        if (ex instanceof MethodArgumentNotValidException || ex instanceof HttpMessageNotReadableException
	                || ex instanceof MissingServletRequestParameterException || ex instanceof TypeMismatchException) {

	            code = CinglevueExceptionCode.BAD_REQUEST.toString();
	            message = CinglevueExceptionCode.BAD_REQUEST.getDescription();
	            status = HttpStatus.BAD_REQUEST.value();

	        } else if(ex instanceof HttpMediaTypeNotSupportedException){
	           
	            code = CinglevueExceptionCode.BAD_REQUEST.toString();
	            message = CinglevueExceptionCode.BAD_REQUEST.getDescription();
	            status = HttpStatus.NOT_ACCEPTABLE.value();
	            
	        } else {
	            code = "ERROR";
	            message = "ERROR";
	            status = HttpStatus.INTERNAL_SERVER_ERROR.value();
	        }
	        response.setStatus(status);

	        setStatusHeaders(response, code, message);

	        logger.error(ex.getMessage());
	    }
}
