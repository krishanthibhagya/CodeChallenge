package com.cinglevue.schools.controller;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cinglevue.schools.appication.school.SchoolApplicationService;
import com.cinglevue.schools.appication.school.SchoolDTO;
import com.cinglevue.schools.appication.school.SchoolResponseDTO;

@Controller
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class SchoolController extends HTTPResponseHandler {
	
	@Autowired
	SchoolApplicationService schoolApplicationService;
	
	@RequestMapping(value = "/schools", method = RequestMethod.POST)
	@ResponseBody
	public SchoolResponseDTO createSchool(HttpServletResponse httpServletResponse,
			@Valid @RequestBody SchoolDTO requestDTO) {
		
		SchoolResponseDTO responseDTO =  schoolApplicationService.createSchool(requestDTO);
		
		setStatusHeadersToSuccess(httpServletResponse);
		
		return responseDTO;
	}

}
