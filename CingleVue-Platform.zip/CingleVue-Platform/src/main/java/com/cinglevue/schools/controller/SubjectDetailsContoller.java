package com.cinglevue.schools.controller;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cinglevue.schools.appication.subject.FindSubjectDetailsResponseDTO;
import com.cinglevue.schools.appication.subject.SubjectDetailsApplicationService;
import com.cinglevue.schools.appication.subject.CreateSubjectDetailRequestDTO;
import com.cinglevue.schools.appication.subject.SubjectDetailResponseDTO;

/**
 * The <code> SubjectDetailsContoller </code> is contains all UserDetail related
 * URL mappings.
 * 
 * @author Krishanthi
 * 
 */
@Controller
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class SubjectDetailsContoller extends HTTPResponseHandler {

	@Autowired
	private SubjectDetailsApplicationService subjectDetailsApplicationService;

	/**
	 * Creates a SubjectDetail.
	 * 
	 * @param httpServletResponse the httpServletResponse
	 * @param schoolId the School Id
	 * @param requestDTO the CreateSubjectDetailRequestDTO
	 * @return a SubjectDetailResponseDTO
	 */
	@RequestMapping(value = "/schools/{schoolid}/subjectsdetails", method = RequestMethod.POST)
	@ResponseBody
	public SubjectDetailResponseDTO createSubjectDetail(
			HttpServletResponse httpServletResponse,
			@PathVariable("schoolid") String schoolId,
			@Valid @RequestBody CreateSubjectDetailRequestDTO requestDTO) {

		SubjectDetailResponseDTO responseDTO = subjectDetailsApplicationService
				.createSubjectDetail(schoolId, requestDTO);

		setStatusHeadersToSuccess(httpServletResponse);

		return responseDTO;
	}

	/**
	 * Finds SubjectDetails by Subject.
	 * 
	 * @param httpServletResponse the HttpServletResponse
	 * @param schoolId the School Id
	 * @param page the page number
	 * @param count the number of records for a page
	 * @param subject the subject
	 * @param sortBy the sort parameter
	 * @param sortdirection the sort direction
	 * @return a FindSubjectDetailsResponseDTO
	 */
	@RequestMapping(value = "/schools/{schoolid}/subjectsdetails", method = RequestMethod.GET)
	@ResponseBody
	public FindSubjectDetailsResponseDTO findSubjectDetails(
			HttpServletResponse httpServletResponse,
			@PathVariable("schoolid") String schoolId,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "count", required = true) int count,
			@RequestParam(value = "subject", required = true) String subject,
			@RequestParam(value = "sortby", required = false, defaultValue = "latestY3") String sortBy,
			@Valid @RequestParam(value = "sortdirection", required = false, defaultValue = "ASC") Direction sortdirection) {

		FindSubjectDetailsResponseDTO responseDTO = subjectDetailsApplicationService
				.findSubjectDetails(page, count, sortBy, sortdirection, subject);

		return responseDTO;
	}

}
