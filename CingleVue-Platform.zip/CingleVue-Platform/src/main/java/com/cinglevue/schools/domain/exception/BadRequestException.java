package com.cinglevue.schools.domain.exception;

import org.springframework.http.HttpStatus;

public class BadRequestException extends HTTPException {

	private static final long serialVersionUID = 6081325312979625093L;

	public BadRequestException(String cinglevueStatusCode, String message) {
		super(HttpStatus.BAD_REQUEST, cinglevueStatusCode, message);
	}
	
	public BadRequestException(String cinglevueStatusCode) {
        super(HttpStatus.BAD_REQUEST, cinglevueStatusCode);
    }

}
