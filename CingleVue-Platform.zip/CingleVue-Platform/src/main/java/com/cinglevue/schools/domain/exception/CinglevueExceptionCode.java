package com.cinglevue.schools.domain.exception;

public enum CinglevueExceptionCode {
	
	BAD_REQUEST("Not a valid request. Please ensure all required parameters are present and in valid format."), 
	
	INVALID_PAGE_INDEX("Index page cannot be less than to zero."),
	
    INVALID_PAGE_SIZE("Page size cannot be less than or equal to zero.");
	
	private final String explanation;

    private CinglevueExceptionCode(String explanation) {
        this.explanation = explanation;
    }

    /**
     * Return the explanation of this status code.
     */
    public String getDescription() {
        return explanation;
    }

}
