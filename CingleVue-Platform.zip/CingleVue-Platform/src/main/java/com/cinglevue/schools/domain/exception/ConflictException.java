package com.cinglevue.schools.domain.exception;

import org.springframework.http.HttpStatus;

public class ConflictException extends HTTPException {

	private static final long serialVersionUID = 2113284318853481896L;

	public ConflictException(String cinglevueStatusCode, String message) {
		super(HttpStatus.CONFLICT, cinglevueStatusCode, message);
	}

}
