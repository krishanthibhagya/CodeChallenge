package com.cinglevue.schools.domain.exception;

public enum ExceptionCode {
	
	 SCHOOL_NOT_FOUND("School not found for the given parameters."),
	 
	 SCHOOL_NAME_ALREADY_EXIST("School name cannot be duplicated."), 
	 
	 SUBJECT_DETAILS_ALREADY_EXIST("Subject details cannot be duplicated.");
	 
	 private final String explanation;

	    private ExceptionCode(String explanation) {
	        this.explanation = explanation;
	    }

	    /**
	     * Return the explanation of this status code.
	     */
	    public String getDescription() {
	        return explanation;
	    }

}
