package com.cinglevue.schools.domain.exception;

import org.springframework.http.HttpStatus;

public class NotFoundException extends HTTPException {

	private static final long serialVersionUID = 6992979250316712891L;

	public NotFoundException(String cinglevueStatusCode) {
        super(HttpStatus.NOT_FOUND, cinglevueStatusCode);
    }
	
	public NotFoundException(String cinglevueStatusCode, String message) {
		super(HttpStatus.NOT_FOUND, cinglevueStatusCode, message);
	}
	
	public NotFoundException(String cinglevueStatusCode, String message, Throwable e) {
		super(HttpStatus.NOT_FOUND, cinglevueStatusCode, message, e);
	}

}
