package com.cinglevue.schools.domain.school;

import org.springframework.data.repository.CrudRepository;

/**
 * The <code> SchoolRepository </code> is used to persist data by using Spring Data.
 * 
 * @author Krishanthi
 *
 */
public interface SchoolRepository extends CrudRepository<School, String>{

	/**
	 * Finds School by name.
	 * 
	 * @param schoolName the School name
	 * @return a School
	 */
	School findBySchoolName(String schoolName);

}
