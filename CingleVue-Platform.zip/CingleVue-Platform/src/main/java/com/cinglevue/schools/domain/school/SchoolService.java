package com.cinglevue.schools.domain.school;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cinglevue.schools.domain.exception.ConflictException;
import com.cinglevue.schools.domain.exception.ExceptionCode;
import com.cinglevue.schools.domain.exception.NotFoundException;

/**
 * The <code> SchoolService </code> is the Domain Service which communicates with SchoolRepository.
 * 
 * @author Krishanthi
 * 
 */
@Service
public class SchoolService {

	@Autowired
	private SchoolRepository schoolRepository;

	/**
	 * Creates a School.
	 * 
	 * @param school the School
	 * @return a School
	 */
	public School createSchool(School school) {

		checkSchoolNameUniqueness(school);

		return schoolRepository.save(school);
	}

	/**
	 * Finds a School.
	 * 
	 * @param schoolId the School Id
	 * @return a School
	 */
	public School findSchool(String schoolId) {

		School school = schoolRepository.findOne(schoolId);

		if (school == null) {
			throw new NotFoundException(ExceptionCode.SCHOOL_NOT_FOUND.toString(),
					ExceptionCode.SCHOOL_NOT_FOUND.getDescription());
		}

		return school;
	}

	/**
	 * Checks School name uniqueness.
	 * 
	 * @param school the School
	 * @throws ConflictException,if there is a School with same name
	 */
	private void checkSchoolNameUniqueness(School school) {

		School duplicateSchool = schoolRepository.findBySchoolName(school
				.getSchoolName());

		if (duplicateSchool != null) {
			throw new ConflictException(
					ExceptionCode.SCHOOL_NAME_ALREADY_EXIST.toString(),
					ExceptionCode.SCHOOL_NAME_ALREADY_EXIST.getDescription());
		}

	}

}
