package com.cinglevue.schools.domain.subject;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

/**
 * The <code> SubjectDetailsRepository </code> is used to persist data by using Spring Data.
 * 
 * @author Krishanthi
 *
 */
public interface SubjectDetailsRepository extends
		CrudRepository<SubjectDetail, String> {

	SubjectDetail findBySubjectAndSchoolSchoolId(String subject,
			String schoolId);

	Page<SubjectDetail> findBySubject(String subject, Pageable pageable);

}
