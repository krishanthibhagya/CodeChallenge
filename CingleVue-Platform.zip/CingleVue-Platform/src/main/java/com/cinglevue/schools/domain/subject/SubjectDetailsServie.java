package com.cinglevue.schools.domain.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.cinglevue.schools.domain.exception.ConflictException;
import com.cinglevue.schools.domain.exception.ExceptionCode;

/**
 * The <code> SubjectDetailsServie </code> is the Domain Service which communicates with SubjectDetailsRepository.
 * 
 * @author Krishanthi
 * 
 */
@Service
public class SubjectDetailsServie {

	@Autowired
	private SubjectDetailsRepository subjectRepository;

	/**
	 * Creates a SubjectDetail.
	 * 
	 * @param subjectDetail A SubjectDetail
	 * @return a SubjectDetail
	 */
	public SubjectDetail createSubjectDetail(SubjectDetail subjectDetail) {

		checkSubjectNameUniqueness(subjectDetail);

		return subjectRepository.save(subjectDetail);
	}

	/**
	 * Checks subject name uniqueness.
	 * 
	 * @param subjectDetail the SubjectDetail
	 * @throws ConflictException,if there is a Subject with same name
	 */
	private void checkSubjectNameUniqueness(SubjectDetail subjectDetail) {

		SubjectDetail duplucateSubjectDetails = subjectRepository
				.findBySubjectAndSchoolSchoolId(subjectDetail.getSubject(),
						subjectDetail.getSchool().getSchoolId());

		if (duplucateSubjectDetails != null) {
			throw new ConflictException(
					ExceptionCode.SUBJECT_DETAILS_ALREADY_EXIST.toString(),
					ExceptionCode.SUBJECT_DETAILS_ALREADY_EXIST
							.getDescription());
		}

	}

	/**
	 * Finds SubjectDetails.
	 * 
	 * @param subject the Subject
	 * @param pageable the Spring data Pageble
	 * @return a list of SubjectDetail
	 */
	public Page<SubjectDetail> findSubjectDetails(String subject, Pageable pageable) {
		
		return subjectRepository.findBySubject(subject, pageable);
	}

}
