package com.cinglevue.schools.infrastructure.repository;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.ejb.HibernatePersistence;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

/**
 * The <code> RepositoryConfig </code> is contains all key values for mysql configuration.
 * 
 * @author Krishanthi
 *
 */
@Configuration
@EnableJpaRepositories("com.cinglevue.schools")
public class RepositoryConfig {
	
	 @Value("${incentivio.database.mysql.driver}")
		private String databaseDriver = null;
		
	    @Value("${incentivio.database.mysql.hostUrl}")
	    private String hostUrl = null;
	    
	    @Value("${incentivio.database.mysql.username}")
		private String dbUsername = null;
		
	    @Value("${incentivio.database.mysql.password}")
	    private String dbPassword = null;

	    @Value("${incentivio.database.mysql.dialectproperty}")
		private String hibernateDialectProperty = null;
	    
	    @Value("${incentivio.database.mysql.dialectvalue}")
	    private String hibernateDialectValue = null;
		
	    @Value("${incentivio.database.mysql.showsqlproperty}")
	    private String hibernateShowSqlProperty = null;
	    
	    @Value("${incentivio.database.mysql.showsqlvalue}")
	    private String hibernateShowSqlValue = null;
	    
	    @Value("${incentivio.database.mysql.packagestoscan}")
		private String packagesToScan = null;
	    
	    @Value("${incentivio.database.mysql.ddlautogenerateproperty}")
	    private String ddlAutoGenerateProperty = null;
	    
	    @Value("${incentivio.database.mysql.ddlautogenerateValue}")
	    private String ddlAutoGenerateValue = null;

		@Bean
		public DataSource dataSource() {
			DriverManagerDataSource dataSource = new DriverManagerDataSource();

			dataSource.setDriverClassName(databaseDriver);
			dataSource.setUrl(hostUrl);
			dataSource.setUsername(dbUsername);
			dataSource.setPassword(dbPassword);

			return dataSource;
		}

		@Bean
		public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
			LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
			entityManagerFactoryBean.setDataSource(dataSource());
			entityManagerFactoryBean.setPersistenceProviderClass(HibernatePersistence.class);
			entityManagerFactoryBean.setPackagesToScan(packagesToScan);

			entityManagerFactoryBean.setJpaProperties(hibProperties());

			return entityManagerFactoryBean;
		}

		private Properties hibProperties() {
			Properties properties = new Properties();
			properties.put(hibernateDialectProperty, hibernateDialectValue);
			properties.put(hibernateShowSqlProperty, hibernateShowSqlValue);
			properties.put(ddlAutoGenerateProperty, ddlAutoGenerateValue);
			return properties;
		}

		@Bean
		public JpaTransactionManager transactionManager() {
			JpaTransactionManager transactionManager = new JpaTransactionManager();
			transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
			return transactionManager;
		}

}
