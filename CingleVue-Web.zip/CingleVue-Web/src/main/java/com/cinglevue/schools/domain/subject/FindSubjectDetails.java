package com.cinglevue.schools.domain.subject;

import java.util.List;

import com.cinglevue.schools.util.ResultPaging;

public class FindSubjectDetails {

	private List<SubjectDetail> details;

	private ResultPaging resultPaging;

	public List<SubjectDetail> getDetails() {
		return details;
	}

	public void setDetails(List<SubjectDetail> details) {
		this.details = details;
	}

	public ResultPaging getResultPaging() {
		return resultPaging;
	}

	public void setResultPaging(ResultPaging resultPaging) {
		this.resultPaging = resultPaging;
	}

}
