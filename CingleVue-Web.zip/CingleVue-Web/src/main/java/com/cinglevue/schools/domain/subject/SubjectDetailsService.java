package com.cinglevue.schools.domain.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.cinglevue.schools.infrastructure.config.RestServiceUrlConfig;
import com.cinglevue.schools.util.AdapterErrorHandlerUtil;

/**
* The <code> SubjectDetailsService </code> is contains service methods to <br/>
* communicate with CingleVue Platfrom.
* 
* @author Krishanthi
*
*/
@Service
public class SubjectDetailsService {
	
	@Autowired
	private RestServiceUrlConfig restServiceUrlConfig;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AdapterErrorHandlerUtil adapterErrorHandlerUtil;
	
	public FindSubjectDetails findSubjectDetails(String schoolid) {
		FindSubjectDetails findSubjectDetails = null;
        String url = restServiceUrlConfig.getFindSubjectSDeltailsUrl();

        try {
        	findSubjectDetails = restTemplate.getForObject(url,FindSubjectDetails.class, schoolid);

        } catch (HttpStatusCodeException e) {
            adapterErrorHandlerUtil.handleHTTPStatusCodeException(e);
        } catch (Exception e) {
            adapterErrorHandlerUtil.throwInternalServerErrorException();
        }

        return findSubjectDetails;
    }

	

}
