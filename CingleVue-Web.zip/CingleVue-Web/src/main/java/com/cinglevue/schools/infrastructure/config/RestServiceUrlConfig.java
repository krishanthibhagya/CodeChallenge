package com.cinglevue.schools.infrastructure.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


/**
 * The <code> RestServiceUrlConfig </code> is contains all key values for Service URLs.
 * 
 * @author Krishanthi
 *
 */
@Component
public class RestServiceUrlConfig {

	@Value("${com.cinglevue.platfrom.url}")
	private String platfromUrl = null;

	@Value("${com.cinglevue.platform.createschoolurl}")
	private String createSchoolUrl = null;

	@Value("${com.cinglevue.platform.createsubjectdetailurl}")
	private String createSubjectDetailUrl = null;

	@Value("${com.cinglevue.platform.findsubjectdeltailsurl}")
	private String findSubjectSDeltailsUrl = null;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public String getPlatfromUrl() {
		return platfromUrl;
	}

	public String getCreateSchoolUrl() {
		return platfromUrl + createSchoolUrl;
	}

	public String getCreateSubjectDetailUrl() {
		return platfromUrl + createSubjectDetailUrl;
	}

	public String getFindSubjectSDeltailsUrl() {
		return platfromUrl + findSubjectSDeltailsUrl;
	}

}
