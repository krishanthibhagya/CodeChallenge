package com.cinglevue.schools.util;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

import com.cinglevue.schools.util.exception.HTTPException;

@Component
public class AdapterErrorHandlerUtil {

	public void handleHTTPStatusCodeException(HttpStatusCodeException e)
			throws HTTPException {

		String code = "";
		String message = "";

		try {
			code = e.getResponseHeaders().get("cinglevue-code").get(0);
			message = e.getResponseHeaders().get("cinglevue-message").get(0);
		} catch (NullPointerException ex) {

			// status code and status message will be sent as blank in the
			// header
		}

		HttpStatus status = HttpStatus.valueOf(e.getStatusCode().value());

		throw new HTTPException(status, code, message);
	}

	public void throwInternalServerErrorException() throws HTTPException {
		throw new HTTPException(HttpStatus.INTERNAL_SERVER_ERROR, "ERROR",
				"Internal Server Error");
	}

}
